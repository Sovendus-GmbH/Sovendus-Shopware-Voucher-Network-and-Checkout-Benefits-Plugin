# 1.0.0
- Initiale Version
# 1.0.1
- Entferne unbenutzte Variablen